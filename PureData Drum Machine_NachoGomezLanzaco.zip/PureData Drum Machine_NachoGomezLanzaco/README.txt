//
Open the file Drum_Machine.pd and follow the instructions in the User Interface. For better performance use headphones.
To use new samples, copy the .wav files into the this folder and rename them as the preset ones.
//

Developed by Nacho Gomez-Lanzaco
